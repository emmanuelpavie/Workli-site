# Workli – React + Vite + Tailwind (TypeScript)

Development:
```
npm install
npm run dev
```
