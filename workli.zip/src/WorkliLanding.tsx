// simplified placeholder component for WorkliLanding
export default function WorkliLanding(){return <div>Workli Landing Placeholder</div>}
